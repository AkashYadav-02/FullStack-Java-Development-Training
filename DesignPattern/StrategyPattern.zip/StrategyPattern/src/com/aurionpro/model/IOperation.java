package com.aurionpro.model;

public interface IOperation {
	public int doOperation(int a , int b);

}
