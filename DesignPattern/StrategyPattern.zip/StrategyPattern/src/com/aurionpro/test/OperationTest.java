package com.aurionpro.test;

import com.aurionpro.model.AddOperation;
import com.aurionpro.model.OperationStrategy;
import com.aurionpro.model.MultiplyOperation;
public class OperationTest {
	public static void main(String[] args) {
		
		OperationStrategy op=new OperationStrategy(new AddOperation());
		System.out.println(" Addition of 20 and 30 is :  "+op.doOperation(20, 30));
		 op=new OperationStrategy(new MultiplyOperation()); 
		System.out.println(" Multiplication of 20 and 30 is :  "+op.doOperation(20, 30));
	}

}
