package com.aurionpro.model;

public class Premium implements    IHat{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Premium";
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 2000;
	}

	@Override
	public String getDiscription() {
		// TODO Auto-generated method stub
		return " this is Premium hat";
	}
	
}
