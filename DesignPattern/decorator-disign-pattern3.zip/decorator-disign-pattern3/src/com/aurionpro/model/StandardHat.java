package com.aurionpro.model;

public class StandardHat  implements  IHat{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Standard";
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 200;
	}

	@Override
	public String getDiscription() {
		// TODO Auto-generated method stub
		return "  standard hat";
	}
	
	

}