export interface recipi {
 id:string,
 title:string,
 imgUrl:string,
 ingredient:string[]
    
}
