package com.aurionpro.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.model.ICoach;
@RestController
@RequestMapping("/coach")
public class CricketController {
 
	private ICoach icoach;

	public CricketController(ICoach icoach) {
		super();
		this.icoach = icoach;
	}
	@GetMapping("/show")
	public String show() {
		   return  this.icoach.showdetails();
	}
	
}
