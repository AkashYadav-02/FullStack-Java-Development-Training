package com.aurionpro.model;

public interface ICoach {
	

	public String showdetails();

}
