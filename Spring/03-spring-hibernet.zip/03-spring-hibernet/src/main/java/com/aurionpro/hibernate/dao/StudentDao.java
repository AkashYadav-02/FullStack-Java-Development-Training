package com.aurionpro.hibernate.dao;

import com.aurionpro.hibernate.entity.Student;

public interface StudentDao {
 public void  addStudent(Student student);
}
