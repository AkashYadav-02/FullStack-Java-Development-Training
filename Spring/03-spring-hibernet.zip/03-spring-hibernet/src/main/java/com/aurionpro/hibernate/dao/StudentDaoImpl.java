package com.aurionpro.hibernate.dao;

import org.springframework.stereotype.Repository;

import com.aurionpro.hibernate.entity.Student;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class StudentDaoImpl implements StudentDao {

	private EntityManager manager;
   
	public StudentDaoImpl(EntityManager manager) {
		super();
		this.manager = manager;
	}

	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		this.manager.persist(student);
	}

}
